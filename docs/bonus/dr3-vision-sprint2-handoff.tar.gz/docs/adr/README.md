# Architecture Decision Records (ADRs)

This directory contains short, dated, immutable records of the technical and architectural decisions made on DR3-Vision. Read every ADR before writing code; they encode constraints that are not always obvious from the codebase.

## Index

### Sprint 1 — foundation

| # | Title | Status |
|---|---|---|
| 0001 | Tech stack | Accepted |
| 0002 | Fleet host | Accepted |
| 0003 | Domain & routing | Accepted |
| 0004 | PIN authentication | Accepted |
| 0005 | Photo storage & retention | Accepted |
| 0006 | Offline queue strategy | Accepted |
| 0007 | Audit log design & retention | Accepted |
| 0008 | Brand theme | Accepted |
| 0009 | MyMRC integration via Playwright | Accepted (deferred reconsideration on API access) |
| 0010 | CIP data handling | Deferred (V2.2 scope) |
| 0011 | Processor Form / deconstruction-line workflow | Accepted (V2.1 scope) — *Superseded in part by ADR-0019 §1 (formula correction)* |

### Sprint 1 — additions and clarifications

| # | Title | Status |
|---|---|---|
| 0012 | Sprint 1 clarifications | Accepted |
| 0013 | Production deploy pattern | Accepted |
| 0014 | Canonical brand mark lock | Accepted |
| 0015 | i18n architecture | Accepted |
| 0016 | Microsoft Entra ID SSO (managers + admins) | Accepted |
| 0017 | Admin Settings panel | Accepted |
| 0018 | Audit log viewer | Accepted |

### Sprint 2 — bonus management + landing + observability

| # | Title | Status |
|---|---|---|
| 0019 | **Bonus Management System** | Accepted |
| 0020 | **Vision Dashboard tile landing** | Accepted |
| 0021 | **M365 Graph mail-send for payroll PDF delivery** | Accepted |
| 0022 | **Fleet observability wire-in** (supersedes T-018 deferral) | Accepted |

## How to write a new ADR

1. Number it sequentially (`0023-...`), dated, short title.
2. Use the template:
    - **Context** — what's the situation
    - **Decision** — what we chose
    - **Alternatives considered** — what we rejected and why
    - **Consequences** — what this commits us to
3. Once accepted, ADRs are immutable. To overturn one, write a new ADR that supersedes it.
4. Cross-reference the charter section that prompted the decision.
5. Update this README index.
