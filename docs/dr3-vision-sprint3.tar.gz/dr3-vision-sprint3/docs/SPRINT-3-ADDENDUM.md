# Sprint 3 Addendum — Historical Data Import + Mail-Send + Observability

**Sprint owner:** Bill (operations@svdp.us)
**Sprint goal:** Land historical bonus data (Jan 2025 → Jun 2026) in production AND wire M365 Mail.Send for payroll delivery AND wire GlitchTip for error capture. One deploy. Ship today (Mon 2026-06-08) before Tue 2026-06-09 Period 13 production go-live.
**ADR governing this sprint:** ADR-0023.

## Ticket waves (multi-agent dispatch order)

Wave letters indicate dependency ordering. All tickets in a wave can dispatch in parallel.

### Wave A — Schema + governance (no app code yet)

#### T-300 — Migration: 20260608_historical_data_import
**Owner:** db/migrations agent
**Files:**
- `prisma/migrations/20260608_historical_data_import/migration.sql` (provided in Sprint 3 bundle)
- `prisma/schema.prisma` (apply patches per `src-patches/schema.prisma.patch.md`)
**Acceptance:**
- `prisma migrate deploy` applies cleanly on a fresh DB.
- `prisma format` succeeds; `prisma validate` succeeds.
- Replay against a Sprint-2-addendum-state DB applies all six DDL statements idempotently (the `IF NOT EXISTS` / `ADD VALUE IF NOT EXISTS` clauses ensure this).
- `prisma generate` produces a client that includes the `BonusImport` and `BonusEmployeeAlias` models.

#### T-301 — ADR-0023 ship to repo
**Owner:** docs agent
**Files:**
- `docs/adr/0023-historical-data-import.md` (provided)
- Update `docs/adr/INDEX.md` to list ADR-0023.

#### T-302 — Patrick Dills user seed
**Owner:** seed agent
**Files:**
- `prisma/seed/users.csv` (provided — adds one row)
- `prisma/seed/README.md` updated to note 6-user baseline.

### Wave B — State machine + dashboard (TypeScript code; depends on Wave A migration only for type generation)

#### T-310 — State machine: historical_imported transitions
**Owner:** bonus-state agent
**Files:**
- `src/lib/bonus/state-machine.ts` (apply patches per `src-patches/state-machine.ts.patch.md`)
- `tests/unit/bonus/state-machine-historical.test.ts` (provided in `src-patches/`)
**Acceptance:**
- All existing state-machine tests pass.
- The new test file passes (12 new test cases).
- TypeScript compiles; `BonusPayPeriodState` union includes `'historical_imported'`.

#### T-311 — Dashboard tiles: remove bulk-upload
**Owner:** dashboard agent
**Files:**
- `src/lib/dashboard-tiles.ts` (apply patch per `src-patches/dashboard-tiles.ts.patch.md`)
- `tests/unit/lib/dashboard-tiles.test.ts` add the bulk-upload-absent assertion.
**Acceptance:**
- `DASHBOARD_TILES` no longer contains a tile with `key='bulk-upload'`.
- Visible-tiles snapshot for managers updates accordingly.

#### T-312 — Bonus access: Patrick Dills tile visibility
**Owner:** bonus-access agent
**Files:** `src/lib/bonus/access.ts` (no code change expected — Patrick gets the Bonus tile by the existing manager+ rule), tests/integration/bonus/access.test.ts add a Patrick fixture.
**Acceptance:**
- Patrick (manager, primary_site_code=eugene) is granted Eugene-scoped Bonus access.
- Patrick is NOT in any Eugene `bonus_signature_chains` slot.
- A Patrick-as-actor attempt to sign a period as facility signer is rejected by the existing signature-flow guard.

### Wave C — Seed runtime (TypeScript/JS; depends on Wave A + B)

#### T-320 — seedHistoricalImport in prisma/seed.mjs
**Owner:** seed agent
**Files:**
- `prisma/seed.mjs` (apply additions per `src-patches/seed.mjs.additions.md`)
- All seven CSVs in `prisma/seed/historical/` (provided in bundle):
  - `bonus_employees_historical.csv` (94 rows)
  - `bonus_employee_aliases_historical.csv` (128 rows)
  - `bonus_pay_periods_2025.csv` (52 rows)
  - `bonus_pay_periods_historical_state.csv` (76 rows)
  - `bonus_daily_entries_historical.csv` (5,158 rows)
  - `bonus_imports.csv` (1 row)
  - `reconciliation.json` (forensic report — not consumed by seed, archived for reference)
- `prisma/seed/historical/source-archive/Bonus_Spread_Sheet_2026.xlsx` (the source spreadsheet, archived)
**Acceptance:**
- Fresh-DB seed produces: 6 users, 104 pay periods, 94 bonus_employees, 128 bonus_employee_aliases, 1 bonus_import, 5,158 bonus_daily_entries.
- Re-run is a no-op (idempotency check on `bonus_imports.source_sha256`).
- Audit-log row count grows by ~5,260 (5,158 entries + ~104 period transitions).
- `assertCounts` floor checks pass.
- Reconciliation: sum of `legacy_total_cents` across all imported daily entries equals `bonus_imports.total_legacy_dollars × 100` = $11,377,600 cents exactly.

#### T-321 — Eager PDF generation for historical periods
**Owner:** pdf agent
**Files:**
- `scripts/generate-historical-pdfs.mjs` (new) — invokes the existing PDF generator for each `historical_imported` period.
- Wire into `prisma/seed.mjs` as the final step after `seedHistoricalImport`.
**Acceptance:**
- After seed completes, every `historical_imported` period has a non-null `pdf_storage_key`.
- PDFs use as-paid (legacy) totals per ADR-0023 Q1.
- PDF attestation language is import-specific ("Imported from `Bonus_Spread_Sheet_2026.xlsx` SHA-256 `e172dd…`, not signed by facility or ops").
- Re-run is a no-op (skip if `pdf_storage_key` already set).

### Wave D — Decimal UI (depends on Wave A schema)

#### T-330 — Daily-entry UI accepts decimals
**Owner:** ui agent
**Files:**
- `src/app/bonus/[siteSlug]/period/[periodId]/page.tsx` (or wherever daily-entry input lives)
- `src/components/bonus/DailyEntryRow.tsx` — update input validation to `\d{1,4}(\.\d)?`
- Add `helperText` showing "Up to one decimal place" on focus.
**Acceptance:**
- User can enter `23.5` and it persists as `23.5` in the database.
- Negative input still rejected.
- Soft-warn threshold (>200) still applies on integer-floor portion.
- Calculator output for fractional input matches the integer-floor result (calculator already floors per existing safeguard).

### Wave E — Concurrent: T-122 / T-123

#### T-122 — M365 Mail.Send production wiring
**Owner:** payroll agent
**Files:**
- Configure `M365_TENANT_ID`, `M365_CLIENT_ID`, `M365_CLIENT_SECRET` env vars on CHAD-HQ.
- `src/lib/payroll/mail-send.ts` — flip from sandbox to prod endpoint.
**Acceptance:**
- Test send to `bill.barnard@svdp.us` succeeds with the test PDF.
- Graph audit log records the send.
- The Period 13 closure (Mon Jun 22) will trigger a real payroll send to `payroll@svdp.us`.

#### T-123 — GlitchTip DSN production wiring
**Owner:** observability agent
**Files:**
- Configure `GLITCHTIP_DSN` env var on CHAD-HQ.
- `src/lib/observability/error-capture.ts` — flip the sample rate from 0 to 1.0 for prod.
**Acceptance:**
- Deliberate error in a /admin sub-route surfaces in the GlitchTip project within 5 minutes.
- The observability tile already points at `noc-mastercontrol.barnardhq.com/status/dr3-vision`; no change there.

## Pre-deploy checklist (Bill)

```
[ ] Migration runs cleanly on staging clone of prod DB
[ ] Seed runs cleanly; assertCounts passes
[ ] Patrick Dills row exists in users; is NOT in bonus_signature_chains for Eugene
[ ] At least one /bonus/eugene historical period renders with PDF
[ ] Historical period state transition shows in audit log
[ ] Reconciliation total = $113,776.00 (sum of legacy_total_cents = 11,377,600)
[ ] T-122 mail-send tested end-to-end with bill.barnard@svdp.us
[ ] T-123 deliberate error appears in GlitchTip
[ ] Tests green (existing 648 + new ~15 = ~663 total)
[ ] CHANGELOG.md updated
```

## Post-deploy verification (Tue Jun 9 morning, before Janette/Rick start entry)

```
[ ] Janette opens /bonus/woodland and sees 2025 + 2026 history populated
[ ] Rick opens /bonus/eugene and sees 2025 + 2026 history populated
[ ] Patrick opens /bonus/eugene (Entra SSO first sign-in, admin activates account) and sees Eugene data
[ ] Period 13 of 2026 is in 'draft' state; Janette/Rick begin daily entry
[ ] No historical-period state can be edited directly (assertEntriesEditable refuses)
```

## Rollback plan

If Sprint 3 fails post-deploy:

1. The migration is forward-only (adds columns/enum value/tables). A full rollback would require:
   - `DROP TABLE bonus_imports CASCADE; DROP TABLE bonus_employee_aliases CASCADE;`
   - `ALTER TABLE bonus_daily_entries DROP COLUMN legacy_total_cents, DROP COLUMN import_session_id, DROP COLUMN import_provenance;`
   - `ALTER TABLE bonus_pay_periods DROP COLUMN legacy_total_payout_cents, DROP COLUMN imported_with_legacy_formula, DROP COLUMN import_session_id;`
   - `ALTER TABLE bonus_daily_entries ALTER COLUMN mattress_count TYPE INTEGER USING mattress_count::INTEGER;`
   - `ALTER TYPE BonusPayPeriodState DROP VALUE 'historical_imported';` (only if no rows reference it — otherwise CASCADE delete all historical_imported periods first)
2. Less destructive alternative: leave schema in place, simply DELETE all rows with the import session id:
   - `DELETE FROM audit_log WHERE actor_label = 'system:historical-import';`
   - `DELETE FROM bonus_daily_entries WHERE import_session_id = 'import_2026_06_08_historical';`
   - `UPDATE bonus_pay_periods SET state = 'draft', legacy_total_payout_cents = NULL, imported_with_legacy_formula = false, import_session_id = NULL WHERE import_session_id = 'import_2026_06_08_historical';`
   - `DELETE FROM bonus_employee_aliases WHERE import_session_id = 'import_2026_06_08_historical';`
   - `DELETE FROM bonus_employees WHERE notes LIKE '%import_2026_06_08_historical%';`
   - `DELETE FROM bonus_imports WHERE id = 'import_2026_06_08_historical';`
3. Tue Jun 9 Janette/Rick still start entry on Period 13 cleanly (no schema changes there affect the new-period flow).
