# Operator Runbook — Sprint 3 Deploy (Mon 2026-06-08)

This runbook drives the Sprint 3 deploy on CHAD-HQ. Time budget: ~60–90 minutes of active work, including verification.

## Pre-flight (Mon Jun 8 afternoon)

### 1. Backup production DB (always before a schema migration)
```bash
ssh chad-hq
cd /opt/dr3-vision
docker compose exec -T postgres pg_dump -U dr3vision dr3vision \
  | gzip > /var/backups/dr3-vision/pre-sprint3-$(date -u +%Y%m%d-%H%M).sql.gz
ls -lah /var/backups/dr3-vision/ | tail -3
```

### 2. Confirm Sprint 2 addendum is the deploy baseline
```bash
cd /opt/dr3-vision
git log --oneline -3
# Expected: most recent commit is sprint-2-addendum tip or login-cinematic patch
```

### 3. Confirm Period 12 of 2026 is still `skipped` (sanity)
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT site_id, period_year, period_number, state FROM bonus_pay_periods WHERE period_year = 2026 AND period_number = 12;"
# Expected: 2 rows (Woodland + Eugene), both state='skipped'
```

### 4. Confirm baseline row counts
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT 'users' AS table, COUNT(*) FROM users
   UNION ALL SELECT 'bonus_pay_periods', COUNT(*) FROM bonus_pay_periods
   UNION ALL SELECT 'bonus_signature_chains', COUNT(*) FROM bonus_signature_chains
   UNION ALL SELECT 'bonus_employees', COUNT(*) FROM bonus_employees
   UNION ALL SELECT 'bonus_daily_entries', COUNT(*) FROM bonus_daily_entries;"
# Expected: users>=5, bonus_pay_periods=52, bonus_signature_chains=2,
#           bonus_employees=0, bonus_daily_entries=0
```

## Deploy

### 5. Pull Sprint 3 branch
```bash
cd /opt/dr3-vision
git fetch origin
git checkout sprint-3-historical-import
git pull
```

### 6. Run the migration
```bash
docker compose run --rm app npx prisma migrate deploy
# Expected: Migration 20260608_historical_data_import applied
# Should be fast (DDL only, no data movement)
```

### 7. Generate prisma client
```bash
docker compose run --rm app npx prisma generate
```

### 8. Run the seed (this is the big one)
```bash
docker compose run --rm app node prisma/seed.mjs 2>&1 | tee /tmp/seed-$(date -u +%Y%m%d-%H%M).log
# Expected runtime: ~3-5 minutes
# Expected output ends with:
#   ✔ historical import complete
#   ✔ seed complete: { sites: 2, users: 6, ..., bonus_daily_entries: 5158, bonus_imports: 1 }
```

If the seed fails:
- Check `/tmp/seed-*.log` for the error
- Re-run is safe (idempotent by `source_sha256`)
- If a specific row caused the failure, examine the CSV and fix; the previously-seeded rows are preserved

### 9. Generate historical PDFs
```bash
docker compose run --rm app node scripts/generate-historical-pdfs.mjs 2>&1 | tee /tmp/pdfs-$(date -u +%Y%m%d-%H%M).log
# Expected: ~100 PDFs generated to R2; ~5 minutes
```

### 10. Restart app + cron
```bash
docker compose up -d --force-recreate app cron
docker compose logs --tail=50 app
docker compose logs --tail=20 cron
# Both should reach READY without errors
```

## Verification

### 11. Verify counts
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT 'users' AS table, COUNT(*) FROM users
   UNION ALL SELECT 'bonus_pay_periods', COUNT(*) FROM bonus_pay_periods
   UNION ALL SELECT 'bonus_employees', COUNT(*) FROM bonus_employees
   UNION ALL SELECT 'bonus_employee_aliases', COUNT(*) FROM bonus_employee_aliases
   UNION ALL SELECT 'bonus_imports', COUNT(*) FROM bonus_imports
   UNION ALL SELECT 'bonus_daily_entries', COUNT(*) FROM bonus_daily_entries
   UNION ALL SELECT 'historical_imported_periods', COUNT(*) FROM bonus_pay_periods WHERE state = 'historical_imported';"
# Expected:
#   users >= 6
#   bonus_pay_periods = 104   (52 of 2025 + 52 of 2026)
#   bonus_employees >= 94
#   bonus_employee_aliases >= 128
#   bonus_imports = 1
#   bonus_daily_entries >= 5158
#   historical_imported_periods = ~52 (all 2025 + a few 2026)
```

### 12. Verify the dollar reconciliation
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT SUM(legacy_total_cents) AS legacy_cents, SUM(legacy_total_cents)::DECIMAL / 100 AS legacy_dollars
   FROM bonus_daily_entries WHERE import_session_id = 'import_2026_06_08_historical';"
# Expected: legacy_cents = 11377600, legacy_dollars = 113776.00
```

### 13. Verify Patrick Dills
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT u.email, u.role, s.code AS primary_site, u.processor_role, u.is_active
   FROM users u LEFT JOIN sites s ON u.primary_site_id = s.id
   WHERE u.email = 'patrick.dills@svdp.us';"
# Expected: patrick.dills@svdp.us | manager | eugene | Lead | false

docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT s.code, c.facility_signer_user_id, c.ops_signer_user_id, c.facility_override_actor_ids, c.ops_override_actor_ids
   FROM bonus_signature_chains c JOIN sites s ON c.site_id = s.id
   WHERE s.code = 'eugene';"
# Expected: eugene | <Rick's UUID> | <Kelsey's UUID> | <Bill,Kelsey UUIDs> | <Bill UUID>
# Verify Patrick's UUID is NOT in any of those four columns

docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT be.full_name, be.site_id, be.user_id, u.email
   FROM bonus_employees be LEFT JOIN users u ON be.user_id = u.id
   WHERE be.full_name = 'Patrick Dills';"
# Expected: 1 row, full_name=Patrick Dills, user_id=<Patrick's user UUID>, email=patrick.dills@svdp.us
```

### 14. Spot-check a historical period
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT pp.period_year, pp.period_number, pp.state, pp.legacy_total_payout_cents, pp.total_payout_cents, pp.imported_with_legacy_formula, pp.pdf_storage_key IS NOT NULL AS has_pdf
   FROM bonus_pay_periods pp JOIN sites s ON pp.site_id = s.id
   WHERE s.code = 'woodland' AND pp.period_year = 2025 AND pp.period_number IN (1, 13, 26)
   ORDER BY pp.period_number;"
# Expected: 3 rows, all state='historical_imported', has_pdf=true, legacy_total_payout_cents > 0 (for 2025 periods that received entries)
```

### 15. Verify audit log growth
```bash
docker compose exec -T postgres psql -U dr3vision -d dr3vision -c \
  "SELECT actor_label, action, table_name, COUNT(*)
   FROM audit_log
   WHERE actor_label = 'system:historical-import'
   GROUP BY actor_label, action, table_name
   ORDER BY 4 DESC;"
# Expected:
#   system:historical-import | insert | bonus_daily_entries  | ~5158
#   system:historical-import | update | bonus_pay_periods    | ~104
```

### 16. Browser smoke test
- Open https://dr3-vision.svdp.us (your Entra SSO)
- Navigate /bonus/woodland → confirm history list shows 2025 periods
- Click into Period 1 of 2025 → confirm daily entries + signed PDF link
- Navigate /bonus/eugene → confirm history list shows 2025 + 2026 periods
- Confirm Patrick Dills appears in the Eugene employee roster
- Confirm Bulk Upload tile is gone from the dashboard

### 17. T-122 Mail.Send verification (optional, can defer to T-122 dedicated test)
```bash
docker compose run --rm app node scripts/test-mail-send.mjs bill.barnard@svdp.us
# Should log a Graph request ID and "✔ sent"
```

### 18. T-123 GlitchTip verification (optional)
```bash
curl https://dr3-vision.svdp.us/api/admin/_test_glitchtip
# Returns 500 deliberately; verify in GlitchTip dashboard within 5 minutes
```

## Post-deploy

### 19. Tag the deploy
```bash
git tag -a sprint-3-historical-import-deployed -m "Sprint 3 deployed $(date -u +%Y-%m-%dT%H:%M:%SZ)"
git push origin sprint-3-historical-import-deployed
```

### 20. Notify Janette + Rick (Tue Jun 9 morning before they start)
```
Subject: DR3-Vision history is now live

Janette / Rick,

DR3-Vision now has all bonus history from Jan 2025 through Jun 2026 loaded.
When you open the bonus page tomorrow morning you'll see every past pay
period as "historical-imported." That's correct — they're read-only.

Today's work (Period 13, Tue Jun 9 - Mon Jun 22) goes in as normal.

Patrick Dills can now sign into Vision and see Eugene bonus data; he is not
a signer on the Eugene chain so the workflow is unchanged for Rick.

Reach out with any questions.

Bill
```

## Failure modes

| Symptom | Cause | Fix |
|---|---|---|
| Migration fails `ALTER TYPE ... ADD VALUE` | Old Postgres version | Postgres 16 supports this; if running older, run the ALTER TYPE manually outside a transaction |
| Seed fails "operations@svdp.us not found" | users.csv not seeded yet | Run baseline seed first; `seedHistoricalImport` should be wired AFTER `seedUsers` |
| Seed crashes mid-insert | Constraint violation on (bonus_employee_id, entry_date) | Means a duplicate slipped through dedup; check `reconciliation.json` anomalies, re-export CSVs from `parse-historical-v3.py`, redeploy |
| Reconciliation total ≠ $113,776.00 | Partial seed | Re-run seed; idempotency check ensures no double-counting |
| Patrick Dills can't log in | Inactive user (expected — admin activates on first Entra sign-in) | Bill activates via `/admin/users` panel |
| PDFs missing for some historical periods | scripts/generate-historical-pdfs.mjs failed mid-run | Re-run; idempotent (skips periods with non-null pdf_storage_key) |
