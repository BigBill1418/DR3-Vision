# CHANGELOG entry — Sprint 3 (prepend this block to the top of CHANGELOG.md)

## 2026-06-08 — Sprint 3 deploy: historical bonus data import + T-122 + T-123 (ADR-0023)

**Headline:** 17 months of historical bonus data (Jan 2025 → Jun 2026, $113,776.00 / 5,158 daily entries / 94 unique processors after dedup, Stockton folded to Woodland) lands in Vision before Tue Jun 9 production go-live. Bulk upload UI is intentionally **not** built — design pivoted to seed-time delivery via in-conversation parser (ADR-0023 Q19).

**Schema** (`prisma/migrations/20260608_historical_data_import/migration.sql`):
- `BonusPayPeriodState` enum: added `historical_imported`.
- `bonus_pay_periods`: added `legacy_total_payout_cents`, `imported_with_legacy_formula`, `import_session_id`.
- `bonus_daily_entries`: `mattress_count` `Int → Decimal(5,1)`; added `legacy_total_cents`, `import_session_id`, `import_provenance` JSONB.
- New table `bonus_imports` (one row per import session, SHA-256 idempotency key).
- New table `bonus_employee_aliases` (variant_name → canonical_employee_id mappings).
- Partial indexes on `import_session_id` for both forensic lookups.

**State machine** (`src/lib/bonus/state-machine.ts`):
- New legal transitions: `draft → historical_imported`, `skipped → historical_imported` (both admin-only).
- New out-edge: `historical_imported → amended` (via existing admin amendment workflow).
- `historical_imported` is NOT in `EDITABLE_STATES` — admin must amend before editing.
- New test file `tests/unit/bonus/state-machine-historical.test.ts` (~12 cases).

**Dashboard tiles** (`src/lib/dashboard-tiles.ts`):
- Removed the `bulk-upload` tile entirely (ADR-0023 Q20). Historical import is a one-shot operation, not a feature.

**Seeds** (`prisma/seed/`):
- `users.csv` gained Patrick Dills (`patrick.dills@svdp.us`, manager, eugene primary site, processor_role=Lead). Excluded from Eugene signature chain per ADR-0023 (separation of duties: also a `BonusEmployee` at Eugene).
- New directory `prisma/seed/historical/`:
  - `bonus_employees_historical.csv` (94 rows; deterministic UUIDs via MD5 of canonical_name|site)
  - `bonus_employee_aliases_historical.csv` (128 variant → canonical mappings)
  - `bonus_pay_periods_2025.csv` (52 rows; 26 periods × 2 sites for 2025)
  - `bonus_pay_periods_historical_state.csv` (76 state-transition records)
  - `bonus_daily_entries_historical.csv` (5,158 rows, ~1.15 MB)
  - `bonus_imports.csv` (1 row, the import session)
  - `reconciliation.json` (forensic anomaly + provenance report)
  - `source-archive/Bonus_Spread_Sheet_2026.xlsx` (the source spreadsheet, SHA-256 `e172dd106d04e2244bb7b55c00be6fcf17caebada1daea0de915c6489d86805f`)
- `prisma/seed.mjs` gained `seedHistoricalImport()` (idempotent by SHA-256; ~3-5 minute runtime).

**Production-side observability** (concurrent tickets):
- T-122 — M365 Mail.Send credentials wired for prod; payroll send on Period 13 close (Mon Jun 22) will go live.
- T-123 — GlitchTip DSN wired; error capture active.

**Things flagged but NOT changed**:
- Production calculator (`src/lib/bonus/calculator.ts`) is **correct**. Earlier concerns about a possible tiered-substitution bug were resolved on read: the calculator uses additive semantics correctly. The misleading walkthrough text in older docs (`(50 × 1.00) + (20 × 0.25) = $75`) had bad parenthesized arithmetic but a correct result; the code matches the spreadsheet's implicit formula.
- Historical Woodland totals use `threshold_high=75` (the spreadsheet's old formula). Going forward, `processor_bonus_rules` still has the corrected `threshold_high=74`. The `legacy_total_payout_cents` column preserves the as-paid amount; `total_payout_cents` would carry the corrected-formula recompute (informational only for historical periods).

**Operator-visible changes** (Tue Jun 9 morning):
- /bonus/woodland and /bonus/eugene show 17 months of read-only history.
- Patrick Dills can sign in (after Bill activates the account via /admin/users on first Entra sign-in) and view Eugene data; Patrick cannot sign periods.
- Bulk Upload tile is gone from the dashboard.
- Daily-entry inputs at both sites now accept up to one decimal place (e.g., 23.5).

**Tests**: existing 648 + new ~15 = ~663 total. All gates green.
**Audit log growth from this deploy**: ~75–100 MB (5,158 daily-entry insert rows + 104 period state-transition rows, full provenance JSONB per row).
