// Apply this diff to prisma/schema.prisma to bring the declarative schema
// in line with migration 20260608_historical_data_import (ADR-0023).
//
// Three edits in three locations. Each shows the surrounding context for
// `apply-patch`-style application; replace the original block with the
// "AFTER" block exactly.

// ─────────────────────────────────────────────────────────────────────
// EDIT 1 — BonusPayPeriodState enum: add `historical_imported`.
// Location: enum BonusPayPeriodState definition.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
// enum BonusPayPeriodState {
//   draft
//   pending_signatures
//   partially_signed
//   signed
//   paid
//   amended
//   skipped
// }

// AFTER:
//
// enum BonusPayPeriodState {
//   draft
//   pending_signatures
//   partially_signed
//   signed
//   paid
//   amended
//   skipped
//   historical_imported // ADR-0023 — periods loaded from the historical spreadsheet
// }

// ─────────────────────────────────────────────────────────────────────
// EDIT 2 — BonusPayPeriod model: dual-total + import-session fields.
// Location: existing BonusPayPeriod block, right before/around the
//           `total_payout_cents Int?` field.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
//   // Computed at sign time, locked thereafter (re-computed only on amendment)
//   total_payout_cents Int?
//
//   created_at DateTime @default(now())

// AFTER:
//
//   // Computed at sign time, locked thereafter (re-computed only on amendment).
//   // For historical_imported periods, this stores the corrected-formula
//   // calculator output (threshold_high=74 for Woodland).
//   total_payout_cents Int?
//
//   // Sprint 3 / ADR-0023: dual-total storage for historical_imported periods.
//   // legacy_total_payout_cents is the sum of as-paid spreadsheet Total cells
//   // (threshold_high=75 historical Woodland formula, unchanged Eugene). When
//   // imported_with_legacy_formula = true, PDF and payroll-export read from
//   // legacy_total_payout_cents; the corrected total is informational only.
//   legacy_total_payout_cents    Int?
//   imported_with_legacy_formula Boolean @default(false)
//   import_session_id            String?
//   bonus_import                 BonusImport? @relation(fields: [import_session_id], references: [id])
//
//   created_at DateTime @default(now())

// ─────────────────────────────────────────────────────────────────────
// EDIT 3 — BonusDailyEntry model: Decimal(5,1) + provenance fields.
// Location: existing BonusDailyEntry block.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
// model BonusDailyEntry {
//   id                String        @id @default(uuid())
//   bonus_employee_id String
//   bonus_employee    BonusEmployee @relation(fields: [bonus_employee_id], references: [id])
//   bonus_pay_period_id String         // was bonus_month_id
//   bonus_pay_period    BonusPayPeriod @relation(fields: [bonus_pay_period_id], references: [id])
//
//   entry_date     DateTime @db.Date
//   mattress_count Int // 0..999 valid, soft-warn above 200
//   note           String? // optional HR annotation, does NOT affect math
// ...
// }

// AFTER:
//
// model BonusDailyEntry {
//   id                String        @id @default(uuid())
//   bonus_employee_id String
//   bonus_employee    BonusEmployee @relation(fields: [bonus_employee_id], references: [id])
//   bonus_pay_period_id String         // was bonus_month_id
//   bonus_pay_period    BonusPayPeriod @relation(fields: [bonus_pay_period_id], references: [id])
//
//   entry_date     DateTime @db.Date
//   // Decimal(5,1) per ADR-0023 Q6 + Q18. Historical Eugene rows have 23.5,
//   // 30.5 etc; production UI accepts one decimal place at both sites going
//   // forward. Soft-warn above 200 still applies (calculator floors are
//   // robust to fractional input).
//   mattress_count Decimal @db.Decimal(5, 1)
//   note           String? // optional HR annotation, does NOT affect math
//
//   // Sprint 3 / ADR-0023: provenance for historical imports. NULL for
//   // production entries; populated for every row loaded via the historical
//   // spreadsheet import. See bonus_imports for the session this row belongs
//   // to; import_provenance is the raw forensic payload (source_sheet_name,
//   // source_row_index, source_count_col, source_total_col, raw_count,
//   // raw_total, total_source, formula_version, original_site_code, etc).
//   legacy_total_cents Int?
//   import_session_id  String?
//   import_provenance  Json?
//   bonus_import       BonusImport? @relation(fields: [import_session_id], references: [id])
//
//   entered_by_user_id String
//   entered_by         User     @relation("BonusEntryAuthor", fields: [entered_by_user_id], references: [id])
//   entered_at         DateTime @default(now())
//
//   @@unique([bonus_employee_id, entry_date])
//   @@index([bonus_pay_period_id])
//   @@index([entry_date])
//   @@index([import_session_id])
//   @@map("bonus_daily_entries")
// }

// ─────────────────────────────────────────────────────────────────────
// EDIT 4 — NEW model: BonusImport.
// Location: append after BonusSignatureChain (end of file).
// ─────────────────────────────────────────────────────────────────────

// AFTER (append):
//
// model BonusImport {
//   id                       String   @id
//   source_filename          String
//   source_sha256            String   @unique
//   source_archive_path      String?  // repo-relative path; promoted to R2 key in follow-up ticket
//   imported_by_user_id      String
//   imported_by              User     @relation(fields: [imported_by_user_id], references: [id])
//   imported_at              DateTime @default(now())
//   total_entries            Int
//   total_mattress_count     Decimal  @db.Decimal(10, 1)
//   total_legacy_dollars     Decimal  @db.Decimal(12, 2)
//   stockton_origin_entries  Int      @default(0)
//   stockton_origin_dollars  Decimal  @db.Decimal(12, 2) @default(0)
//   anomaly_count            Int      @default(0)
//   auto_sum_count           Int      @default(0)
//   reconciliation_json      Json?
//   notes                    String?
//
//   pay_periods   BonusPayPeriod[]
//   daily_entries BonusDailyEntry[]
//
//   @@index([imported_at])
//   @@map("bonus_imports")
// }
//
// model BonusEmployeeAlias {
//   id                    String         @id @default(uuid())
//   variant_name          String
//   canonical_employee_id String
//   canonical_employee    BonusEmployee  @relation(fields: [canonical_employee_id], references: [id])
//   import_session_id     String?
//   created_at            DateTime       @default(now())
//
//   @@unique([variant_name, canonical_employee_id])
//   @@index([canonical_employee_id])
//   @@index([variant_name])
//   @@map("bonus_employee_aliases")
// }

// ─────────────────────────────────────────────────────────────────────
// EDIT 5 — User model: add the back-reference to BonusImport.
// Location: User model relations list.
// ─────────────────────────────────────────────────────────────────────
//
// AFTER (append to the relations list in `model User { ... }`):
//
//   bonus_imports_authored                  BonusImport[]

// ─────────────────────────────────────────────────────────────────────
// EDIT 6 — BonusEmployee model: add the back-reference to BonusEmployeeAlias.
// Location: BonusEmployee model relations list.
// ─────────────────────────────────────────────────────────────────────
//
// AFTER (append to the relations list in `model BonusEmployee { ... }`):
//
//   aliases       BonusEmployeeAlias[]
