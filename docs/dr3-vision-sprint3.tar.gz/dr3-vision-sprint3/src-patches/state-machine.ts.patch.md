// Patch for src/lib/bonus/state-machine.ts per ADR-0023 (Q4, Q8).
//
// Three small edits:
//   1. Add 'historical_imported' to the BonusPayPeriodState union type
//   2. Add the two new admin-only transitions to ALLOWED_TRANSITIONS
//   3. Add the new admin-only edges to ADMIN_ONLY_TRANSITIONS
//
// The terminal-and-amendable behavior comes from declaring
// historical_imported -> amended as the single out-edge.

// ─────────────────────────────────────────────────────────────────────
// EDIT 1 — BonusPayPeriodState union type.
// Location: existing export type around line 50.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
// export type BonusPayPeriodState =
//   | 'draft'
//   | 'pending_signatures'
//   | 'partially_signed'
//   | 'signed'
//   | 'paid'
//   | 'amended'
//   | 'skipped';

// AFTER:
//
// export type BonusPayPeriodState =
//   | 'draft'
//   | 'pending_signatures'
//   | 'partially_signed'
//   | 'signed'
//   | 'paid'
//   | 'amended'
//   | 'skipped'
//   | 'historical_imported'; // ADR-0023 — periods loaded from the historical spreadsheet

// ─────────────────────────────────────────────────────────────────────
// EDIT 2 — ALLOWED_TRANSITIONS table.
// Location: existing constant declaration.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
// export const ALLOWED_TRANSITIONS: Readonly<
//   Record<BonusPayPeriodState, readonly BonusPayPeriodState[]>
// > = {
//   draft: ['pending_signatures', 'skipped'],
//   pending_signatures: ['partially_signed'],
//   partially_signed: ['signed'],
//   signed: ['paid', 'amended'],
//   paid: ['amended'],
//   amended: ['pending_signatures'],
//   skipped: [],
// };

// AFTER:
//
// export const ALLOWED_TRANSITIONS: Readonly<
//   Record<BonusPayPeriodState, readonly BonusPayPeriodState[]>
// > = {
//   // `draft -> skipped` (T-203 / ADR-0019.1) and `draft -> historical_imported`
//   // (ADR-0023) are both admin-only edges into terminal-ish states. The
//   // historical_imported state is amendable: a period imported from the
//   // spreadsheet can be unlocked for correction via the existing amendment
//   // workflow, restarting the signature flow at pending_signatures.
//   draft: ['pending_signatures', 'skipped', 'historical_imported'],
//   pending_signatures: ['partially_signed'],
//   partially_signed: ['signed'],
//   signed: ['paid', 'amended'],
//   paid: ['amended'],
//   amended: ['pending_signatures'],
//   skipped: ['historical_imported'], // ADR-0023 — a pre-cutover-skipped period that turns out to have historical data
//   historical_imported: ['amended'], // ADR-0023 — amendable via existing admin workflow (Q4)
// };

// ─────────────────────────────────────────────────────────────────────
// EDIT 3 — ADMIN_ONLY_TRANSITIONS set.
// Location: existing constant declaration.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
// export const ADMIN_ONLY_TRANSITIONS: ReadonlySet<`${BonusPayPeriodState}->${BonusPayPeriodState}`> =
//   new Set(['draft->skipped']);

// AFTER:
//
// export const ADMIN_ONLY_TRANSITIONS: ReadonlySet<`${BonusPayPeriodState}->${BonusPayPeriodState}`> =
//   new Set([
//     'draft->skipped',
//     'draft->historical_imported',  // ADR-0023 Q8 — bulk import is admin-only
//     'skipped->historical_imported', // ADR-0023 Q8 — same
//   ]);

// ─────────────────────────────────────────────────────────────────────
// EDIT 4 — EDITABLE_STATES does NOT change.
// historical_imported is intentionally NOT editable directly. To correct
// a historical period's entries, an admin first transitions
// historical_imported -> amended via the existing amendment workflow,
// then edits in `amended` state, then re-signs.
// ─────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────
// EDIT 5 — Tests for new transitions (NEW file).
// Location: tests/unit/bonus/state-machine-historical.test.ts
// Provided in src-patches/state-machine-historical.test.ts.
// ─────────────────────────────────────────────────────────────────────
