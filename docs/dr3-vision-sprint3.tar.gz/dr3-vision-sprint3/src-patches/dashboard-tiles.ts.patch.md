// Patch for src/lib/dashboard-tiles.ts per ADR-0023 Q20.
//
// The historical data import ships as a one-shot seed bundle, not a runtime
// feature. Per Q19 + Q20 the pivot was made to design Vision as the single
// source of truth — there's no need to upload a file Bill already provided
// in conversation. The bulk-upload tile is removed entirely.
//
// Single edit: delete the bulk-upload tile from COMING_SOON_TILES.

// ─────────────────────────────────────────────────────────────────────
// EDIT — Remove the bulk-upload tile.
// Location: COMING_SOON_TILES array, ~line 110.
// ─────────────────────────────────────────────────────────────────────

// BEFORE:
//
// const COMING_SOON_TILES: readonly DashboardTile[] = [
//   {
//     key: 'bulk-upload',
//     label: 'Bulk Data Upload',
//     description: 'Import historical loads and processor records from spreadsheets.',
//     icon: 'Upload',
//     route: '#',
//     status: 'coming-soon',
//     scope: 'manager+',
//   },
//   {
//     key: 'photo-annotation',
//     label: 'Photo Annotation Canvas',
//     ...
//   },
//   ...
// ];

// AFTER:
//
// const COMING_SOON_TILES: readonly DashboardTile[] = [
//   // bulk-upload tile removed per ADR-0023 Q20 — historical data import is a
//   // one-shot seed delivery (Q19, Q21), not a runtime feature.
//   {
//     key: 'photo-annotation',
//     label: 'Photo Annotation Canvas',
//     ...
//   },
//   ...
// ];

// ─────────────────────────────────────────────────────────────────────
// Test updates (NEW assertions to add):
// ─────────────────────────────────────────────────────────────────────
//
// In tests/unit/lib/dashboard-tiles.test.ts, add:
//
// describe('bulk-upload tile removal (ADR-0023)', () => {
//   it('does NOT register a bulk-upload tile', () => {
//     const keys = DASHBOARD_TILES.map((t) => t.key);
//     expect(keys).not.toContain('bulk-upload');
//   });
// });
