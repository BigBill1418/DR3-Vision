#!/usr/bin/env python3
"""
DR3-Vision historical data import — master parser (v2, dynamic layout).

v1 used fixed-stride column iteration which silently dropped entries on sheets
with irregular layouts (3-col -> 4-col -> 3-col patterns, e.g., Eugene Sept
2025 has 109 cols mixing both formats). v2 dynamically maps row 0 to find
every date column and infers per-day total column from the layout.

Per ADR-0023 (Q1-Q22 design locks).
"""

import hashlib
import json
import re
import uuid
from collections import defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path

import pandas as pd

XLSX = Path("/mnt/user-data/uploads/Bonus_Spread_Sheet_2026__1_.xlsx")
OUT = Path("/home/claude/dr3-vision-sprint3/prisma/seed/historical")
OUT.mkdir(parents=True, exist_ok=True)

with open(XLSX, "rb") as f:
    SOURCE_SHA256 = hashlib.sha256(f.read()).hexdigest()
SOURCE_FILENAME = XLSX.name
IMPORT_SESSION_ID = "import_2026_06_08_historical"
IMPORT_TIMESTAMP = "2026-06-08T16:30:00-07:00"

# ───────────────────────────────────────────────────────────────────────────
# Q2 locked identity-merge clusters (Bill-confirmed).
# ───────────────────────────────────────────────────────────────────────────
LOCKED_CLUSTERS = {
    "stockton_origin_to_woodland": [
        ("Faisal Mehmood", "woodland", ["Faesal Mehmood", "Faisal Mehmood", "Faisal Mehmood-Processor", "Faisel Mehmood"]),
        ("Mohammad Khan", "woodland", [
            "Mohammad Khan", "Muhammad Khan", "(Mossey) Mohammad Khan", "MK", "Mr Khan",
            "Muhammad Khan Mossey", 'Mohamad Khan "Mossey"', "MK Mossey", "MK Muhammad Khan",
            'Mohammad Khan "Mossey"',
        ]),
        ("Yeimer Sarmiento", "woodland", ["Yeimer Sarmiento", "Yeimar Sarmiento", "Yeimer Sarminto"]),
        ("Akhtar Khan", "woodland", ["Akhtar Khan", "Ahktar Khan", "Akhtar Khan-Processor", "Mr Ahktar Khan"]),
        ("Aamir Mehmood", "woodland", ["Aamir Mehmood", "Aamir Mehmood-MO"]),
        ("Khalid Mehmood", "woodland", ["Khalid Mehmood"]),
        ("Sajid Mehmood", "woodland", ["Sajid Mehmood"]),
    ],
    "woodland_native": [
        ('Eudaldo "Lalo" Sandoval', "woodland", ["Eudaldo Sandoval", 'Eudaldo "Lalo" Sandoval', "Eudaldo Lalo Sandoval"]),
        ("Nelson Barahona Rivas", "woodland", ["Nelson B Rivas", "Nelson Barahona", "Nelson Barahona Rivas", "Nelson Rivas"]),
        ("Franklin Finol Soto", "woodland", ["Frankin Soto", "Franklin Soto", "Franklin Soto (M.O.)", "Franklin Finol Soto"]),
        ("Omar Diaz Vera", "woodland", ["Omar Diaz Vera", "Oamr Diaz Vera"]),
        ("Safdar Ali Nabizada", "woodland", ["Safdar Nabizada", "Safdar Ali Nabizada", 'Safdar "Ali" Nabizada', 'Safdar "Ali " Nabizada']),
    ],
    "eugene": [
        ("Stanley Crux", "eugene", ["Stanley CRux", "Stanley CRux Processor", "Stanley Crux Processor", "Stanley Rux"]),
        ("Patrick Dills", "eugene", ["Patrick Dills", "Patrick Dills Processor", "Patrick Dills Lead"]),
    ],
}

ALIAS_MAP = {}
CANONICAL_TO_VARIANTS = defaultdict(list)
for group_name, clusters in LOCKED_CLUSTERS.items():
    for canonical, site, variants in clusters:
        for v in variants:
            ALIAS_MAP[v.strip()] = (canonical, site)
            CANONICAL_TO_VARIANTS[(canonical, site)].append(v.strip())

ROLE_SUFFIX_RE = re.compile(
    r"\s*[-(]\s*(processor|machine\s*op(erator)?|m\.?o\.?|lead|stryo|floater|mo)\s*\)?\s*$",
    re.IGNORECASE,
)
TERM_SUFFIX_RE = re.compile(r"\s*-\s*term\s*$", re.IGNORECASE)
QUOTED_NICK_RE = re.compile(r'\s*"[^"]*"\s*')

def normalize_name(raw: str) -> tuple[str, bool]:
    n = raw.strip()
    is_term = bool(TERM_SUFFIX_RE.search(n))
    n = TERM_SUFFIX_RE.sub("", n)
    n = ROLE_SUFFIX_RE.sub("", n)
    n_norm = QUOTED_NICK_RE.sub(" ", n)
    n_norm = re.sub(r"\s+", " ", n_norm).strip()
    return n_norm, is_term

def resolve_identity(raw: str, sheet_site: str) -> tuple[str, str, bool]:
    raw = raw.strip()
    is_term = bool(TERM_SUFFIX_RE.search(raw))
    if raw in ALIAS_MAP:
        canonical, site = ALIAS_MAP[raw]
        return (canonical, site, not is_term)
    norm, term_from_norm = normalize_name(raw)
    is_term = is_term or term_from_norm
    if norm in ALIAS_MAP:
        canonical, site = ALIAS_MAP[norm]
        return (canonical, site, not is_term)
    target_site = "woodland" if sheet_site == "stockton" else sheet_site
    return (norm, target_site, not is_term)

# ───────────────────────────────────────────────────────────────────────────
# Sheet classification
# ───────────────────────────────────────────────────────────────────────────
def classify_sheet(name: str) -> tuple[str, int] | None:
    norm = re.sub(r"\s+", " ", name.strip().lower())
    if "template" in norm:
        return None
    m = re.search(r"(20\d{2})", norm)
    if not m:
        return None
    year = int(m.group(1))
    if "woodland" in norm:
        return ("woodland", year)
    if "stockton" in norm or "stockotn" in norm:
        return ("stockton", year)
    if "oregon" in norm or "eugene" in norm:
        return ("eugene", year)
    return ("eugene", year)

# ───────────────────────────────────────────────────────────────────────────
# Dynamic date-column detection (the v2 fix).
# Scans row 0 for ALL date cells, then for each date computes the
# count column (= the date column itself, value below in row N) and
# the total column (= the LAST column before the NEXT date column,
# or the last column with a "Total" header if it's the final day).
# ───────────────────────────────────────────────────────────────────────────
def to_date(cell) -> date | None:
    if pd.isna(cell):
        return None
    if isinstance(cell, (datetime, pd.Timestamp)):
        return cell.date() if hasattr(cell, "date") else cell
    if isinstance(cell, date):
        return cell
    try:
        serial = float(cell)
        if serial < 30000 or serial > 60000:
            return None
        return (datetime(1899, 12, 30) + timedelta(days=int(serial))).date()
    except (ValueError, TypeError):
        return None

def parse_num(cell) -> float | None:
    if pd.isna(cell):
        return None
    try:
        return float(cell)
    except (ValueError, TypeError):
        return None

def find_employee_column(df: pd.DataFrame) -> int | None:
    """Find the column index containing employee names."""
    if df.shape[0] < 1 or df.shape[1] < 1:
        return None
    h0 = str(df.iloc[0, 0]).strip().lower() if pd.notna(df.iloc[0, 0]) else ""
    h1 = str(df.iloc[0, 1]).strip().lower() if df.shape[1] > 1 and pd.notna(df.iloc[0, 1]) else ""
    if h0 == "recycler name" and h1 == "employee name":
        return 1
    if h0 == "name":
        return 0
    if h0 == "employee name":
        return 0
    # Fallback: search first row for "employee name" or "name" anywhere
    for c in range(min(3, df.shape[1])):
        v = str(df.iloc[0, c]).strip().lower() if pd.notna(df.iloc[0, c]) else ""
        if v == "employee name":
            return c
        if v == "name":
            return c
    return None

def map_day_columns(df: pd.DataFrame, summary_keywords=("monthly total", "month total", "total", "sum", "monthtotal")) -> list[dict]:
    """Build a list of {date, count_col, total_col} dicts by walking row 0.

    For each date cell, the count column is that same column (employee count
    rows are below the date). The total column is the LAST 'Total' header
    cell BEFORE the next date cell (or before any summary block like
    'Monthly total').
    """
    date_cols = []
    for c in range(df.shape[1]):
        d = to_date(df.iloc[0, c])
        if d is not None and 2024 <= d.year <= 2027:
            date_cols.append((c, d))

    days = []
    for idx, (c, d) in enumerate(date_cols):
        # Total column: last "Total" header cell between this date col and the next
        next_c = date_cols[idx + 1][0] if idx + 1 < len(date_cols) else df.shape[1]
        total_col = None
        for sub_c in range(c + 1, min(next_c, df.shape[1])):
            h = str(df.iloc[0, sub_c]).strip().lower() if pd.notna(df.iloc[0, sub_c]) else ""
            if h == "total":
                total_col = sub_c
            elif h in summary_keywords and h != "total":
                # Hit a summary header before finding a per-day total — stop scanning
                break
        # If we never found "Total" header (shouldn't happen with this data), use last col
        if total_col is None:
            # Fallback: use the cell at c + (some default span)
            # Standard Eugene = c + 2 (3-col span, total = c + 2)
            # Standard Woodland = c + 3 (4-col span, total = c + 3)
            # We can't know without context; default to c + 2
            total_col = min(c + 2, next_c - 1)
        days.append({"date": d, "count_col": c, "total_col": total_col})
    return days

# ───────────────────────────────────────────────────────────────────────────
# Legacy formulas (for recomputing missing totals per Q6 type 4).
# ───────────────────────────────────────────────────────────────────────────
def legacy_woodland_total(count: float) -> float:
    """Woodland's OLD formula (additive semantics): base $0.50/mattress above 50,
    plus ADDITIONAL $0.25/mattress above 75. Matches spreadsheet's Total cells."""
    if count < 50:
        return 0.0
    base = (count - 50) * 0.50
    high = max(0, count - 75) * 0.25
    return round(base + high, 2)

def eugene_total(count: float) -> float:
    """Eugene's formula (additive semantics): base $1.00/mattress above 50,
    plus ADDITIONAL $0.25/mattress above 100. Matches spreadsheet's Total cells."""
    if count < 50:
        return 0.0
    base = (count - 50) * 1.00
    high = max(0, count - 100) * 0.25
    return round(base + high, 2)

# ───────────────────────────────────────────────────────────────────────────
# Pay-period seeds
# ───────────────────────────────────────────────────────────────────────────
def build_periods(year: int, anchor_pay_date: date) -> list[dict]:
    periods = []
    for n in range(1, 27):
        pay_date = anchor_pay_date + timedelta(days=(n - 1) * 14)
        period_end = pay_date - timedelta(days=4)
        period_start = period_end - timedelta(days=13)
        periods.append({
            "period_number": n,
            "period_year": year,
            "period_start": period_start,
            "period_end": period_end,
            "pay_date": pay_date,
        })
    return periods

PAY_PERIODS_2025 = build_periods(2025, date(2025, 1, 10))
PAY_PERIODS_2026 = build_periods(2026, date(2026, 1, 9))
ALL_PERIODS = PAY_PERIODS_2025 + PAY_PERIODS_2026

def find_period(d: date) -> dict | None:
    for p in ALL_PERIODS:
        if p["period_start"] <= d <= p["period_end"]:
            return p
    return None

# ───────────────────────────────────────────────────────────────────────────
# Main parse loop
# ───────────────────────────────────────────────────────────────────────────
print(f"Source: {SOURCE_FILENAME}")
print(f"SHA-256: {SOURCE_SHA256}")
print()

sheets = pd.read_excel(XLSX, sheet_name=None, header=None)

employees = {}
aliases = []
daily_entries = []
anomalies = []
sheets_processed = []
sheets_skipped = []

EMP_ID = {}
def get_emp(canonical: str, site: str, is_active: bool) -> str:
    key = (canonical, site)
    if key not in EMP_ID:
        EMP_ID[key] = str(uuid.UUID(bytes=hashlib.md5(f"{canonical}|{site}".encode()).digest()))
        employees[key] = {"emp_id": EMP_ID[key], "is_active": is_active, "canonical": canonical, "site": site}
    elif is_active and not employees[key]["is_active"]:
        employees[key]["is_active"] = True
    return EMP_ID[key]

ALIAS_SEEN = set()
def record_alias(variant: str, canonical: str, site: str):
    key = (variant, canonical, site)
    if key not in ALIAS_SEEN:
        ALIAS_SEEN.add(key)
        aliases.append({"variant": variant, "canonical_name": canonical, "target_site_code": site})

for sheet_name, df in sheets.items():
    cls = classify_sheet(sheet_name)
    if cls is None:
        sheets_skipped.append({"name": sheet_name, "reason": "template"})
        continue
    sheet_site, year = cls

    emp_col = find_employee_column(df)
    if emp_col is None:
        sheets_skipped.append({"name": sheet_name, "reason": "no_employee_column"})
        continue

    days = map_day_columns(df)
    if not days:
        sheets_skipped.append({"name": sheet_name, "reason": "no_date_columns"})
        continue

    sheets_processed.append({"name": sheet_name, "sheet_site": sheet_site, "year": year,
                              "days_detected": len(days), "shape": list(df.shape)})

    for day in days:
        d = day["date"]
        count_col = day["count_col"]
        total_col = day["total_col"]
        for row_idx in range(1, df.shape[0]):
            raw_emp = df.iloc[row_idx, emp_col] if emp_col < df.shape[1] else None
            if pd.isna(raw_emp):
                continue
            raw_emp_str = str(raw_emp).strip()
            if not raw_emp_str or raw_emp_str.lower() in ("employee name", "name"):
                continue

            count = parse_num(df.iloc[row_idx, count_col])
            if count is None or count == 0:
                continue

            total = parse_num(df.iloc[row_idx, total_col]) if total_col < df.shape[1] else None
            total_source = "spreadsheet"
            if total is None:
                if sheet_site == "eugene":
                    total = eugene_total(count)
                else:
                    total = legacy_woodland_total(count)
                total_source = "recomputed_from_count"
                anomalies.append({
                    "type": "missing_total_recomputed",
                    "sheet": sheet_name, "row": row_idx, "date": d.isoformat(),
                    "raw_name": raw_emp_str, "count": count, "recomputed_total": total,
                })

            if count > 150:
                anomalies.append({
                    "type": "high_count",
                    "sheet": sheet_name, "row": row_idx, "date": d.isoformat(),
                    "raw_name": raw_emp_str, "count": count, "total": total,
                })

            canonical, target_site, is_active = resolve_identity(raw_emp_str, sheet_site)
            emp_id = get_emp(canonical, target_site, is_active)
            record_alias(raw_emp_str, canonical, target_site)

            period = find_period(d)
            if period is None:
                anomalies.append({
                    "type": "no_period_for_date",
                    "sheet": sheet_name, "row": row_idx, "date": d.isoformat(),
                    "raw_name": raw_emp_str,
                })
                continue

            entry = {
                "bonus_employee_id": emp_id,
                "entry_date": d.isoformat(),
                "mattress_count": count,
                "legacy_total_dollars": round(total, 2),
                "canonical_name": canonical,
                "target_site_code": target_site,
                "period_number": period["period_number"],
                "period_year": period["period_year"],
                "source_sheet_name": sheet_name,
                "source_row_index": row_idx,
                "source_count_col": count_col,
                "source_total_col": total_col,
                "original_site_code": sheet_site,
                "total_source": total_source,
                "raw_count": count,
                "raw_total": total,
                "formula_version": "legacy_pre_2026_06_05" if sheet_site != "eugene" else "eugene_unchanged",
            }
            daily_entries.append(entry)

print(f"Sheets processed: {len(sheets_processed)}")
print(f"Sheets skipped:   {len(sheets_skipped)}")
print(f"Entries parsed (pre-dedup): {len(daily_entries):,}")
print()

# Per-sheet day count (to verify dynamic detection caught more days)
for s in sheets_processed:
    if s["days_detected"] not in (28, 29, 30, 31):
        print(f"  unusual day count: {s['name']!r}: {s['days_detected']} days (shape {s['shape']})")
print()

# ───────────────────────────────────────────────────────────────────────────
# Q16 — Auto-sum duplicate (employee, date) pairs after fold + merge.
# ───────────────────────────────────────────────────────────────────────────
by_key = defaultdict(list)
for e in daily_entries:
    by_key[(e["bonus_employee_id"], e["entry_date"])].append(e)

deduped = []
auto_sum_count = 0
for key, group in by_key.items():
    if len(group) == 1:
        deduped.append(group[0])
        continue
    auto_sum_count += 1
    base = group[0].copy()
    base["mattress_count"] = sum(g["mattress_count"] for g in group)
    base["legacy_total_dollars"] = round(sum(g["legacy_total_dollars"] for g in group), 2)
    base["source_sheet_name"] = ";".join(sorted({g["source_sheet_name"] for g in group}))
    base["source_row_index"] = ";".join(sorted({str(g["source_row_index"]) for g in group}))
    base["original_site_code"] = ";".join(sorted({g["original_site_code"] for g in group}))
    base["merge_strategy"] = "auto_sum"
    base["merge_source_count"] = len(group)
    base["raw_count"] = sum(g["raw_count"] for g in group)
    base["raw_total"] = round(sum(g["raw_total"] for g in group), 2)
    anomalies.append({
        "type": "auto_sum_duplicate",
        "canonical_name": base["canonical_name"],
        "date": base["entry_date"],
        "source_count": len(group),
        "summed_mattress_count": base["mattress_count"],
        "summed_total_dollars": base["legacy_total_dollars"],
        "source_rows": [{"sheet": g["source_sheet_name"], "row": g["source_row_index"],
                          "count": g["mattress_count"], "total": g["legacy_total_dollars"],
                          "site": g["original_site_code"]} for g in group],
    })
    deduped.append(base)

daily_entries = deduped

# ───────────────────────────────────────────────────────────────────────────
# Reconciliation
# ───────────────────────────────────────────────────────────────────────────
total_dollars = round(sum(e["legacy_total_dollars"] for e in daily_entries), 2)
total_count = round(sum(e["mattress_count"] for e in daily_entries), 1)

print(f"Final entries (post-dedup): {len(daily_entries):,}")
print(f"Auto-sum events: {auto_sum_count}")
print(f"Total mattress count: {total_count:,.1f}")
print(f"Total legacy dollars: ${total_dollars:,.2f}")
print()

breakdown = defaultdict(lambda: {"entries": 0, "dollars": 0.0})
for e in daily_entries:
    breakdown[(e["target_site_code"], e["period_year"])]["entries"] += 1
    breakdown[(e["target_site_code"], e["period_year"])]["dollars"] += e["legacy_total_dollars"]

print("Per-site/year breakdown:")
for (site, year), b in sorted(breakdown.items()):
    print(f"  {site:10s} {year}: {b['entries']:5,} entries  ${b['dollars']:>12,.2f}")
print()

stockton_origin = [e for e in daily_entries if "stockton" in e["original_site_code"]]
stockton_dollars = sum(e["legacy_total_dollars"] for e in stockton_origin)
print(f"Stockton-origin entries folded -> Woodland: {len(stockton_origin):,}  (${stockton_dollars:,.2f})")
print()

print(f"Unique employees: {len(employees)}")
print(f"  woodland: {sum(1 for k in employees if k[1] == 'woodland')}")
print(f"  eugene:   {sum(1 for k in employees if k[1] == 'eugene')}")
print()
print(f"Aliases recorded: {len(aliases)}")
print(f"Anomalies logged: {len(anomalies)}")
print()

# Now compute period totals and emit CSVs
period_totals = defaultdict(lambda: {"dollars": 0.0, "count": 0})
for e in daily_entries:
    pk = (e["target_site_code"], e["period_year"], e["period_number"])
    period_totals[pk]["dollars"] += e["legacy_total_dollars"]
    period_totals[pk]["count"] += 1

# ───────────────────────────────────────────────────────────────────────────
# Emit CSVs
# ───────────────────────────────────────────────────────────────────────────
import csv

with open(OUT / "bonus_employees_historical.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["id", "site_code", "full_name", "is_active", "notes"])
    for (canon, site), data in sorted(employees.items()):
        notes = f"Auto-created via {IMPORT_SESSION_ID} from {SOURCE_FILENAME}"
        if not data["is_active"]:
            notes += " | Terminated per historical spreadsheet"
        w.writerow([data["emp_id"], site, canon, str(data["is_active"]).lower(), notes])

with open(OUT / "bonus_employee_aliases_historical.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["variant_name", "canonical_name", "target_site_code", "import_session_id"])
    for a in sorted(aliases, key=lambda x: (x["target_site_code"], x["canonical_name"], x["variant"])):
        w.writerow([a["variant"], a["canonical_name"], a["target_site_code"], IMPORT_SESSION_ID])

with open(OUT / "bonus_pay_periods_2025.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["site_code", "period_number", "period_year", "period_start", "period_end", "pay_date", "notes"])
    for site in ("woodland", "eugene"):
        for p in PAY_PERIODS_2025:
            w.writerow([site, p["period_number"], p["period_year"],
                        p["period_start"].isoformat(), p["period_end"].isoformat(), p["pay_date"].isoformat(),
                        "Historical period seeded for import per ADR-0023"])

with open(OUT / "bonus_pay_periods_historical_state.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["site_code", "period_year", "period_number", "from_state", "to_state",
                "total_payout_cents", "legacy_total_payout_cents", "imported_with_legacy_formula",
                "import_session_id", "notes"])
    touched = set()
    for e in daily_entries:
        touched.add((e["target_site_code"], e["period_year"], e["period_number"]))
    for site in ("woodland", "eugene"):
        for p in PAY_PERIODS_2025:
            touched.add((site, p["period_year"], p["period_number"]))

    for (site, year, pnum) in sorted(touched):
        pk = (site, year, pnum)
        data = period_totals.get(pk, {"dollars": 0.0, "count": 0})
        legacy_cents = int(round(data["dollars"] * 100))

        if year == 2025:
            from_state = "draft"
        elif year == 2026 and pnum == 12:
            from_state = "skipped"
        elif year == 2026 and pnum >= 13:
            continue
        else:
            from_state = "draft"

        notes = f"Imported {data['count']} entries; legacy formula" if data["count"] > 0 else "Empty historical period"
        imported_with_legacy = "true" if site == "woodland" and data["count"] > 0 else "false"
        w.writerow([site, year, pnum, from_state, "historical_imported",
                    legacy_cents, legacy_cents, imported_with_legacy,
                    IMPORT_SESSION_ID, notes])

with open(OUT / "bonus_daily_entries_historical.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "id", "bonus_employee_id", "site_code", "period_year", "period_number",
        "entry_date", "mattress_count", "legacy_total_dollars",
        "source_sheet_name", "source_row_index", "source_count_col", "source_total_col",
        "original_site_code", "total_source", "raw_count", "raw_total", "formula_version",
        "merge_strategy", "merge_source_count", "import_session_id",
    ])
    for e in daily_entries:
        entry_id = str(uuid.UUID(bytes=hashlib.md5(
            f"{IMPORT_SESSION_ID}|{e['bonus_employee_id']}|{e['entry_date']}".encode()).digest()))
        w.writerow([
            entry_id, e["bonus_employee_id"], e["target_site_code"], e["period_year"], e["period_number"],
            e["entry_date"], e["mattress_count"], e["legacy_total_dollars"],
            e["source_sheet_name"], e["source_row_index"], e["source_count_col"], e["source_total_col"],
            e["original_site_code"], e["total_source"], e["raw_count"], e["raw_total"], e["formula_version"],
            e.get("merge_strategy", ""), e.get("merge_source_count", 1), IMPORT_SESSION_ID,
        ])

with open(OUT / "bonus_imports.csv", "w", newline="") as f:
    w = csv.writer(f)
    w.writerow([
        "id", "source_filename", "source_sha256", "imported_by_email",
        "imported_at", "total_entries", "total_mattress_count", "total_legacy_dollars",
        "stockton_origin_entries", "stockton_origin_dollars",
        "anomaly_count", "auto_sum_count", "notes"
    ])
    w.writerow([
        IMPORT_SESSION_ID, SOURCE_FILENAME, SOURCE_SHA256, "operations@svdp.us",
        IMPORT_TIMESTAMP, len(daily_entries), total_count, total_dollars,
        len(stockton_origin), round(stockton_dollars, 2),
        len(anomalies), auto_sum_count,
        "Historical data import per ADR-0023; v3 parser (dynamic layout + additive formulas)"
    ])

recon = {
    "import_session_id": IMPORT_SESSION_ID,
    "source_filename": SOURCE_FILENAME,
    "source_sha256": SOURCE_SHA256,
    "imported_at": IMPORT_TIMESTAMP,
    "totals": {
        "daily_entries": len(daily_entries),
        "mattress_count": total_count,
        "legacy_dollars": total_dollars,
        "unique_employees": len(employees),
        "alias_mappings": len(aliases),
        "auto_sum_events": auto_sum_count,
        "anomalies_logged": len(anomalies),
    },
    "by_site_year": {
        f"{site}_{year}": {"entries": b["entries"], "dollars": round(b["dollars"], 2)}
        for (site, year), b in sorted(breakdown.items())
    },
    "stockton_fold": {
        "entries_folded_to_woodland": len(stockton_origin),
        "dollars_folded_to_woodland": round(stockton_dollars, 2),
    },
    "sheets_processed": sheets_processed,
    "sheets_skipped": sheets_skipped,
    "anomalies_sample": anomalies[:50],
    "anomaly_summary": {
        atype: sum(1 for a in anomalies if a["type"] == atype)
        for atype in {a["type"] for a in anomalies}
    },
}

with open(OUT / "reconciliation.json", "w") as f:
    json.dump(recon, f, indent=2, default=str)

print("Artifacts:")
for p in sorted(OUT.glob("*.csv")):
    size = p.stat().st_size
    rows = sum(1 for _ in open(p)) - 1
    print(f"  {p.name:50s} {size:>10,}B  {rows:>6,} rows")
print(f"  reconciliation.json")
print()
print(f"v1 result: $96,511.25  (fixed-stride, lost entries on irregular layouts)")
print(f"v2 result: ${total_dollars:,.2f}  (dynamic layout, robust)")
print(f"Delta v2-v1: ${total_dollars - 96511.25:+,.2f}")
