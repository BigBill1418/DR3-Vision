# Sprint 3 Bundle — Historical Data Import (ADR-0023)

This bundle contains every artifact needed to ship Sprint 3 — historical bonus
data import + T-122 (M365 Mail.Send) + T-123 (GlitchTip DSN) — to production
on Mon 2026-06-08 before the Tue 2026-06-09 Period 13 production go-live.

## What's inside

```
dr3-vision-sprint3/
├── docs/
│   ├── adr/
│   │   └── 0023-historical-data-import.md  ← Governance ADR (Q1-Q22 locks)
│   ├── operator/
│   │   └── SPRINT-3-RUNBOOK.md             ← Step-by-step deploy + verification
│   ├── CHANGELOG-ENTRY.md                  ← Prepend to repo CHANGELOG.md
│   └── SPRINT-3-ADDENDUM.md                ← Wave-organized ticket bundle
├── prisma/
│   ├── migrations/
│   │   └── 20260608_historical_data_import/
│   │       └── migration.sql               ← Schema changes (DDL only)
│   └── seed/
│       ├── users.csv                       ← Updated (+1 row: Patrick Dills)
│       └── historical/
│           ├── bonus_employees_historical.csv         (94 rows)
│           ├── bonus_employee_aliases_historical.csv  (128 rows)
│           ├── bonus_pay_periods_2025.csv             (52 rows)
│           ├── bonus_pay_periods_historical_state.csv (76 rows)
│           ├── bonus_daily_entries_historical.csv     (5,158 rows, 1.15 MB)
│           ├── bonus_imports.csv                       (1 row)
│           ├── reconciliation.json                     (forensic report)
│           └── source-archive/
│               └── Bonus_Spread_Sheet_2026.xlsx        (the source, ~1.2 MB)
├── src-patches/
│   ├── schema.prisma.patch.md                          ← apply to prisma/schema.prisma
│   ├── state-machine.ts.patch.md                       ← apply to src/lib/bonus/state-machine.ts
│   ├── state-machine-historical.test.ts                ← new test file
│   ├── dashboard-tiles.ts.patch.md                     ← apply to src/lib/dashboard-tiles.ts
│   └── seed.mjs.additions.md                           ← apply to prisma/seed.mjs
├── scripts/                                            ← (reserved for future tooling)
├── parse-historical-v3.py                              ← the parser that produced the CSVs (kept for reproducibility)
└── README.md                                           ← this file
```

## Source-of-truth invariants

- **Source spreadsheet SHA-256:** `e172dd106d04e2244bb7b55c00be6fcf17caebada1daea0de915c6489d86805f`
- **Import session id:** `import_2026_06_08_historical`
- **Import timestamp:** `2026-06-08T16:30:00-07:00`
- **Total entries:** 5,158
- **Total mattress count:** 416,911.0
- **Total legacy dollars:** $113,776.00 (= 11,377,600 cents)
- **Unique canonical employees:** 94 (69 Woodland + 25 Eugene)
- **Alias mappings:** 128
- **Auto-sum events** (Q16): 4
- **Anomalies logged:** 74 (mostly high-count flags + 4 auto-sum events + 18 recomputed-totals)
- **Stockton-origin entries folded into Woodland:** 1,869 (= $41,399.50)

These are dollar-reconciled hard invariants — every deploy verification must
match them exactly. If a re-run of `parse-historical-v3.py` against the same
spreadsheet produces different numbers, treat it as a regression.

## Deploy order

1. **Wave A** (schema + governance, parallel):
   - T-300: apply migration
   - T-301: ADR-0023 ship
   - T-302: Patrick Dills user seed
2. **Wave B** (TypeScript code, parallel, depends on Wave A type generation):
   - T-310: state machine
   - T-311: dashboard tile removal
   - T-312: Patrick access test
3. **Wave C** (seed runtime, depends on Wave A + B):
   - T-320: seedHistoricalImport
   - T-321: eager PDF generation
4. **Wave D** (UI; can dispatch concurrently with Wave C):
   - T-330: decimal entry input
5. **Wave E** (concurrent, independent):
   - T-122: M365 Mail.Send
   - T-123: GlitchTip DSN

See `docs/SPRINT-3-ADDENDUM.md` for per-ticket files and acceptance criteria.

See `docs/operator/SPRINT-3-RUNBOOK.md` for the deploy commands.

## Re-running the parser (if needed)

```bash
cd ~/sprint3/parser
python3 parse-historical-v3.py
# Outputs: prisma/seed/historical/*.csv + reconciliation.json
# Should produce identical bytes given the same source SHA-256.
```

The parser is committed to the repo for reproducibility. If the source
spreadsheet is ever updated (different SHA-256), re-run, generate fresh CSVs,
and treat as a new import session (Bill must approve via ADR-0023.1 or similar).
